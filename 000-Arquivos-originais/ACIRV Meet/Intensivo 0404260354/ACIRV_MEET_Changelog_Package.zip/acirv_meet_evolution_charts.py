from pathlib import Path
import matplotlib.pyplot as plt

MILESTONES = [
  {
    "id": "M0",
    "version": "v0.0",
    "title": "Ideia validada",
    "when": "Ideação / PDF",
    "level": "Conceitual",
    "vs_previous": "Ponto zero: não havia código, apenas problema, público, fluxo e regras do MVP.",
    "changes": [
      "Definição do problema: conciliar agendas sem troca interminável de mensagens.",
      "Definição do diferencial: convite por link + fricção zero para o participante.",
      "Escopo do MVP delimitado: auth do organizador, coleta de disponibilidade, cruzamento, confirmação final e ICS."
    ],
    "metrics": {
      "routes": 0,
      "hooks": 0,
      "migrations": 0,
      "tests": 0
    }
  },
  {
    "id": "M1",
    "version": "v0.1",
    "title": "MVP base implementado",
    "when": "Primeira entrega do Lovable",
    "level": "Estrutural",
    "vs_previous": "Saiu do zero e virou um SaaS navegável com backend, auth, rotas principais e fluxo organizador/participante.",
    "changes": [
      "Criação da base Supabase com profiles, meetings, participants e availabilities.",
      "RLS inicial, trigger de profile no cadastro e RPCs públicas para o participante.",
      "Landing, auth, dashboard, nova reunião, painel, convite, grade de disponibilidade e tela de sucesso.",
      "Primeira versão do design system e do fluxo mobile-first do participante."
    ],
    "metrics": {
      "routes": 8,
      "hooks": 0,
      "migrations": 1,
      "tests": 0
    }
  },
  {
    "id": "M2",
    "version": "v0.2",
    "title": "Estabilização do fluxo público",
    "when": "Rodada de bugfixes",
    "level": "Funcional",
    "vs_previous": "O foco saiu de 'existir' para 'funcionar melhor', com reentrada, sessão e contagem real de respostas.",
    "changes": [
      "Nova RPC get_participant_availabilities para recarregar slots já salvos.",
      "Nova RPC count_meeting_respondents para contar somente participantes que realmente responderam.",
      "Reentrada do participante no mesmo navegador e limpeza de sessão inválida.",
      "Dashboard e MeetingPanel passaram a diferenciar participante pendente de respondente real."
    ],
    "metrics": {
      "routes": 8,
      "hooks": 0,
      "migrations": 2,
      "tests": 0
    }
  },
  {
    "id": "M3",
    "version": "v0.3",
    "title": "Modelo custom de agenda",
    "when": "Redesign do core",
    "level": "Produto",
    "vs_previous": "A reunião deixou de depender só de janela genérica e passou a aceitar slots definidos pelo organizador.",
    "changes": [
      "Criação da tabela meeting_slots e do campo slot_mode em meetings.",
      "RPC pública get_meeting_slots e atualização de get_public_meeting.",
      "NewMeeting virou fluxo em 3 etapas: info, calendário e seleção de horários por dia.",
      "Compatibilidade e InviteAvailability passaram a entender modo legacy (window) e modo custom."
    ],
    "metrics": {
      "routes": 8,
      "hooks": 0,
      "migrations": 5,
      "tests": 0
    }
  },
  {
    "id": "M4",
    "version": "v0.4",
    "title": "Refatoração e performance",
    "when": "Rodada técnica",
    "level": "Técnico",
    "vs_previous": "O projeto ganhou organização interna, query layer e carregamento sob demanda.",
    "changes": [
      "Lazy loading de todas as rotas com Suspense.",
      "Adoção real de TanStack Query para dados públicos, dashboard, painel e sessão do participante.",
      "Criação de tipos compartilhados e hooks dedicados: usePublicMeeting, useParticipantSession, useDashboardMeetings, useMeetingPanel e outros.",
      "Remoção de código legado não usado, como App.css e NavLink."
    ],
    "metrics": {
      "routes": 9,
      "hooks": 6,
      "migrations": 5,
      "tests": 0
    }
  },
  {
    "id": "M5",
    "version": "v0.5",
    "title": "QA e cobertura inicial",
    "when": "Rodada de limpeza/QA",
    "level": "Qualidade",
    "vs_previous": "O projeto passou a ter cobertura automatizada dos blocos mais sensíveis e limpeza de código morto.",
    "changes": [
      "22 testes adicionados cobrindo slots, ICS, sessão do participante e availabilities.",
      "Melhorias de microcopy e limpeza de imports/funções não usadas.",
      "Fluxos de loading, empty, error e success revisados no histórico."
    ],
    "metrics": {
      "routes": 9,
      "hooks": 6,
      "migrations": 5,
      "tests": 22
    }
  },
  {
    "id": "M6",
    "version": "v0.6",
    "title": "Hardening final do domínio",
    "when": "Rodada de correção fina",
    "level": "Domínio + UX",
    "vs_previous": "A agenda ficou mais coerente com a duração real da reunião e a etapa 3 saiu do modelo artificial.",
    "changes": [
      "Correção da RPC create_participant_for_meeting: referência ambígua a edit_token resolvida via migration.",
      "Duração da reunião passou a aceitar apenas inteiros em horas.",
      "Etapa 3 ganhou 'dia inteiro' real (00:00–23:59), validação de sobreposição e deduplicação de slots.",
      "confirmSlot em MeetingPanel passou a usar duration_minutes sempre, corrigindo o fechamento final.",
      "Lógica de slots foi extraída para meeting-slots.ts e a UI da etapa 3 para DayCard.tsx.",
      "Cobertura automatizada subiu para 39 testes."
    ],
    "metrics": {
      "routes": 9,
      "hooks": 8,
      "migrations": 5,
      "tests": 39
    }
  }
]

MATURITY = {
  "Frontend/UX": [
    0,
    5,
    6,
    7,
    8,
    8.2,
    9
  ],
  "Backend e segurança": [
    0,
    6,
    7,
    8,
    8,
    8.2,
    8.8
  ],
  "Domínio de agenda": [
    1,
    4,
    5,
    7,
    7,
    7.2,
    8.8
  ],
  "Qualidade e testabilidade": [
    0,
    1,
    3,
    4,
    6,
    7.2,
    8.8
  ]
}

CURRENT_SNAPSHOT = {
  "Rotas/páginas principais": 9,
  "Hooks dedicados": 8,
  "Migrations Supabase": 5,
  "Arquivos de teste": 5,
  "Casos de teste": 39,
  "Arquivos .tsx": 62,
  "Arquivos .ts": 26,
  "Componentes em src/components": 50
}

OUTDIR = Path("acirv_meet_charts")
OUTDIR.mkdir(exist_ok=True)

labels = [m["id"] for m in MILESTONES]

# 1) Maturidade por dimensão
plt.figure(figsize=(9.5, 4.8))
for name, values in MATURITY.items():
    plt.plot(labels, values, marker="o", linewidth=2, label=name)
plt.ylim(0, 10)
plt.ylabel("Escala analítica (0-10)")
plt.title("Evolução de maturidade do ACIRV MEET por dimensão")
plt.grid(True, axis="y", alpha=0.25)
plt.legend(frameon=False, ncol=2, fontsize=8)
plt.tight_layout()
plt.savefig(OUTDIR / "chart_maturity.png", dpi=180)
plt.close()

# 2) Crescimento de ativos
plt.figure(figsize=(9.5, 4.8))
plt.plot(labels, [m["metrics"]["routes"] for m in MILESTONES], marker="o", label="Rotas")
plt.plot(labels, [m["metrics"]["hooks"] for m in MILESTONES], marker="o", label="Hooks")
plt.plot(labels, [m["metrics"]["migrations"] for m in MILESTONES], marker="o", label="Migrations")
plt.plot(labels, [m["metrics"]["tests"] for m in MILESTONES], marker="o", label="Casos de teste")
plt.title("Crescimento dos ativos do projeto por marco")
plt.ylabel("Quantidade")
plt.grid(True, axis="y", alpha=0.25)
plt.legend(frameon=False, ncol=4, fontsize=8)
plt.tight_layout()
plt.savefig(OUTDIR / "chart_assets.png", dpi=180)
plt.close()

# 3) Snapshot atual do código
plt.figure(figsize=(9, 4.8))
items = list(CURRENT_SNAPSHOT.items())
names = [k for k, v in items][::-1]
values = [v for k, v in items][::-1]
plt.barh(names, values)
plt.title("Snapshot do código atual")
plt.xlabel("Quantidade")
for i, value in enumerate(values):
    plt.text(value + max(values) * 0.01, i, str(value), va="center", fontsize=9)
plt.tight_layout()
plt.savefig(OUTDIR / "chart_snapshot.png", dpi=180)
plt.close()

print("Gráficos gerados em:", OUTDIR.resolve())
