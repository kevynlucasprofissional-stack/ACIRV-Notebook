# ACIRV MEET - Changelog Consolidado de Evolução

Data do documento: 04/04/2026

## 1. Escopo

Este material consolida a evolução do ACIRV MEET desde a fase de ideia até o código atual do SaaS. A leitura combina três fontes:

- planejamento do MVP
- histórico de prompts e decisões
- inspeção direta do código atual

## 2. Síntese executiva

O projeto saiu de uma ideia conceitual e virou um SaaS web com fluxo completo de organizador e participante, backend em Supabase, regras de segurança com RLS, modelos de agenda em modo legado e customizado, camada de hooks com React Query, lazy loading de rotas e cobertura automatizada relevante.

No snapshot atual do código, o projeto apresenta:

- **Rotas/páginas principais:** 9
- **Hooks dedicados:** 8
- **Migrations Supabase:** 5
- **Arquivos de teste:** 5
- **Casos de teste:** 39
- **Arquivos .tsx:** 62
- **Arquivos .ts:** 26
- **Componentes em src/components:** 50

## 3. Linha do tempo

### v0.0 - Ideia validada
- **Quando:** Ideação / PDF
- **Nível de evolução:** Conceitual
- **Mudou em relação à anterior:** Ponto zero: não havia código, apenas problema, público, fluxo e regras do MVP.
- **Principais mudanças:**
  - Definição do problema: conciliar agendas sem troca interminável de mensagens.
  - Definição do diferencial: convite por link + fricção zero para o participante.
  - Escopo do MVP delimitado: auth do organizador, coleta de disponibilidade, cruzamento, confirmação final e ICS.
- **Indicadores do marco:**
  - Rotas: 0
  - Hooks: 0
  - Migrations: 0
  - Casos de teste: 0

### v0.1 - MVP base implementado
- **Quando:** Primeira entrega do Lovable
- **Nível de evolução:** Estrutural
- **Mudou em relação à anterior:** Saiu do zero e virou um SaaS navegável com backend, auth, rotas principais e fluxo organizador/participante.
- **Principais mudanças:**
  - Criação da base Supabase com profiles, meetings, participants e availabilities.
  - RLS inicial, trigger de profile no cadastro e RPCs públicas para o participante.
  - Landing, auth, dashboard, nova reunião, painel, convite, grade de disponibilidade e tela de sucesso.
  - Primeira versão do design system e do fluxo mobile-first do participante.
- **Indicadores do marco:**
  - Rotas: 8
  - Hooks: 0
  - Migrations: 1
  - Casos de teste: 0

### v0.2 - Estabilização do fluxo público
- **Quando:** Rodada de bugfixes
- **Nível de evolução:** Funcional
- **Mudou em relação à anterior:** O foco saiu de 'existir' para 'funcionar melhor', com reentrada, sessão e contagem real de respostas.
- **Principais mudanças:**
  - Nova RPC get_participant_availabilities para recarregar slots já salvos.
  - Nova RPC count_meeting_respondents para contar somente participantes que realmente responderam.
  - Reentrada do participante no mesmo navegador e limpeza de sessão inválida.
  - Dashboard e MeetingPanel passaram a diferenciar participante pendente de respondente real.
- **Indicadores do marco:**
  - Rotas: 8
  - Hooks: 0
  - Migrations: 2
  - Casos de teste: 0

### v0.3 - Modelo custom de agenda
- **Quando:** Redesign do core
- **Nível de evolução:** Produto
- **Mudou em relação à anterior:** A reunião deixou de depender só de janela genérica e passou a aceitar slots definidos pelo organizador.
- **Principais mudanças:**
  - Criação da tabela meeting_slots e do campo slot_mode em meetings.
  - RPC pública get_meeting_slots e atualização de get_public_meeting.
  - NewMeeting virou fluxo em 3 etapas: info, calendário e seleção de horários por dia.
  - Compatibilidade e InviteAvailability passaram a entender modo legacy (window) e modo custom.
- **Indicadores do marco:**
  - Rotas: 8
  - Hooks: 0
  - Migrations: 5
  - Casos de teste: 0

### v0.4 - Refatoração e performance
- **Quando:** Rodada técnica
- **Nível de evolução:** Técnico
- **Mudou em relação à anterior:** O projeto ganhou organização interna, query layer e carregamento sob demanda.
- **Principais mudanças:**
  - Lazy loading de todas as rotas com Suspense.
  - Adoção real de TanStack Query para dados públicos, dashboard, painel e sessão do participante.
  - Criação de tipos compartilhados e hooks dedicados: usePublicMeeting, useParticipantSession, useDashboardMeetings, useMeetingPanel e outros.
  - Remoção de código legado não usado, como App.css e NavLink.
- **Indicadores do marco:**
  - Rotas: 9
  - Hooks: 6
  - Migrations: 5
  - Casos de teste: 0

### v0.5 - QA e cobertura inicial
- **Quando:** Rodada de limpeza/QA
- **Nível de evolução:** Qualidade
- **Mudou em relação à anterior:** O projeto passou a ter cobertura automatizada dos blocos mais sensíveis e limpeza de código morto.
- **Principais mudanças:**
  - 22 testes adicionados cobrindo slots, ICS, sessão do participante e availabilities.
  - Melhorias de microcopy e limpeza de imports/funções não usadas.
  - Fluxos de loading, empty, error e success revisados no histórico.
- **Indicadores do marco:**
  - Rotas: 9
  - Hooks: 6
  - Migrations: 5
  - Casos de teste: 22

### v0.6 - Hardening final do domínio
- **Quando:** Rodada de correção fina
- **Nível de evolução:** Domínio + UX
- **Mudou em relação à anterior:** A agenda ficou mais coerente com a duração real da reunião e a etapa 3 saiu do modelo artificial.
- **Principais mudanças:**
  - Correção da RPC create_participant_for_meeting: referência ambígua a edit_token resolvida via migration.
  - Duração da reunião passou a aceitar apenas inteiros em horas.
  - Etapa 3 ganhou 'dia inteiro' real (00:00–23:59), validação de sobreposição e deduplicação de slots.
  - confirmSlot em MeetingPanel passou a usar duration_minutes sempre, corrigindo o fechamento final.
  - Lógica de slots foi extraída para meeting-slots.ts e a UI da etapa 3 para DayCard.tsx.
  - Cobertura automatizada subiu para 39 testes.
- **Indicadores do marco:**
  - Rotas: 9
  - Hooks: 8
  - Migrations: 5
  - Casos de teste: 39

## 4. Changelog por dimensão

### Produto e fluxo
- Ideia inicial transformada em jornada completa de organizador e participante.
- Criação de reunião evoluiu de janela genérica para seleção direta de dias e faixas.
- Fluxo de reentrada do participante e carregamento de disponibilidade foram introduzidos.
- Compatibilidade passou a operar em modo legado e modo customizado.

### Backend e segurança
- Auth do organizador consolidado com profiles ligados a auth.users.
- RLS aplicado às tabelas centrais.
- RPCs públicas criadas para fluxo sem login do participante.
- Nova tabela meeting_slots adicionada para o modelo custom.
- RPC create_participant_for_meeting corrigida após ambiguidade em edit_token.

### Arquitetura do frontend
- Rotas migradas para lazy loading com Suspense.
- Adoção de TanStack Query em dashboard, painel e fluxos públicos.
- Sessão do participante centralizada em hook dedicado.
- Extração de lógica de slots para módulo separado e UI diária para DayCard.

### Qualidade e testes
- Contagem real de respondentes introduzida.
- Cobertura inicial de 22 testes adicionada.
- Cobertura ampliada para 39 testes com foco em slots, sessão e ICS.
- Validações de sobreposição, deduplicação e all-day adicionadas.

## 5. Comparação direta: ideia inicial vs código atual

- **Problema**
  - **Antes:** Conciliação manual de agenda por mensagens.
  - **Agora:** Fluxo web completo para criação, compartilhamento, resposta e fechamento.
- **Papéis**
  - **Antes:** Organizador e convidado definidos conceitualmente.
  - **Agora:** Separação real entre área autenticada do organizador e fluxo sem login do participante.
- **Disponibilidade**
  - **Antes:** Grade de horários prevista no MVP.
  - **Agora:** Modo legado por janela + modo custom com meeting_slots e faixas por dia.
- **Segurança**
  - **Antes:** Necessidade implícita de proteger dados.
  - **Agora:** RLS, trigger de profile, RPCs públicas controladas e autenticação via Supabase.
- **Evolução técnica**
  - **Antes:** Nenhum código.
  - **Agora:** 9 páginas, 8 hooks, 5 migrations, 39 testes, 50 componentes e 4 bibliotecas internas relevantes.

## 6. Snapshot técnico atual

### Estrutura observada no código

- Rotas principais: `/`, `/auth`, `/dashboard`, `/meetings/new`, `/meetings/:id`, `/invite/:id`, `/invite/:id/availability`, `/invite/:id/success`, `*`
- Hooks dedicados: usePublicMeeting, useParticipantSession, useDashboardMeetings, useMeetingPanel, useParticipantAvailabilities, useAuth, use-toast, use-mobile
- Migrations identificadas: 5
- Arquivos de teste identificados: 5 arquivos `.test.ts`, totalizando 39 casos
- Principais módulos novos de domínio: `meeting-slots.ts`, `DayCard.tsx`

## 7. Observações metodológicas

- Onde o histórico do Lovable descreve mudanças e o código atual confirma a existência dos arquivos/estruturas, o item foi tratado como implementado.
- Onde a evolução veio do histórico de conversa, o changelog registra a progressão como marco de projeto.
- As curvas de maturidade dos gráficos são analíticas, isto é, representam uma leitura comparativa da evolução e não uma métrica de produção coletada automaticamente.

## 8. Código Python para gráficos

O arquivo `acirv_meet_evolution_charts.py` acompanha este material e gera três gráficos:

1. maturidade por dimensão
2. crescimento dos ativos do projeto
3. snapshot do código atual

Trecho principal:

```python
from pathlib import Path
import matplotlib.pyplot as plt

MILESTONES = [
  {
    "id": "M0",
    "version": "v0.0",
    "title": "Ideia validada",
    "when": "Ideação / PDF",
    "level": "Conceitual",
    "vs_previous": "Ponto zero: não havia código, apenas problema, público, fluxo e regras do MVP.",
    "changes": [
      "Definição do problema: conciliar agendas sem troca interminável de mensagens.",
      "Definição do diferencial: convite por link + fricção zero para o participante.",
      "Escopo do MVP delimitado: auth do organizador, coleta de disponibilidade, cruzamento, confirmação final e ICS."
    ],
    "metrics": {
      "routes": 0,
      "hooks": 0,
      "migrations": 0,
      "tests": 0
    }
  },
  {
    "id": "M1",
    "version": "v0.1",
    "title": "MVP base implementado",
    "when": "Primeira entrega do Lovable",
    "level": "Estrutural",
    "vs_previous": "Saiu do zero e virou um SaaS navegável com backend, auth, rotas principais e fluxo organizador/participante.",
    "changes": [
      "Criação da base Supabase com profiles, meetings, participants e availabilities.",
      "RLS inicial, trigger de profile no cadastro e RPCs públicas para o participante.",
      "Landing, auth, dashboard, nova reunião, painel, convite, grade de disponibilidade e tela de sucesso.",
      "Primeira versão do design system e do fluxo mobile-first do participante."
    ],
    "metrics": {
      "routes": 8,
      "hooks": 0,
      "migrations": 1,
```

## 9. Conclusão

Em comparação com o ponto de partida, o ACIRV MEET evoluiu de uma ideia de conciliação de agenda para um SaaS com produto, backend, frontend, segurança, refatoração, testes e hardening de domínio. O maior salto não foi apenas o volume de código, mas a progressão em camadas: primeiro estrutura, depois estabilidade, depois modelo custom, depois arquitetura, depois QA e por fim coerência fina da agenda.