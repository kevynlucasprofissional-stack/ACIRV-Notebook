# Changelog Comparativo — Ecossistema ACIRV

**Comparação:** `Conecta ACIRV - ANTIGO.zip` → `Ecossistema ACIRV - ATUALIZADO 040420260321.zip`  
**Base complementar:** histórico do Lovable + histórico do ChatGPT no ciclo de evolução do projeto.

## 1. Resumo executivo

A versão atual representa uma evolução estrutural importante em relação ao código antigo. O projeto saiu de um **MVP funcional, mas frágil** para um **MVP evoluído em fase de consolidação**.

### Principais saltos de evolução
- **Arquitetura e superfície do produto** ficaram mais amplas e coerentes.
- **Auth/onboarding** foi endurecido, com tratamento de repeated signup e recuperação de `profile` ausente.
- **LGPD / consentimento / visibilidade** passaram a existir como regras reais de produto.
- **Busca de associados** saiu do client-side simples para uma RPC com ranking, normalização e busca por descrição.
- **Sync administrativa** evoluiu para um fluxo mais operacional, com cancelamento, timeout, `content_hash`, `skipped` e logs melhores.
- **Perfil público editável** foi introduzido via `public_overrides`, sem quebrar a sincronização da base.
- **Testes e documentação** deixaram de ser praticamente inexistentes e passaram a formar uma base útil.

### Limite do avanço
Apesar da evolução, a versão atual ainda não é “fechada” em nível de produção. Os principais pontos ainda sensíveis são:
- consistência operacional final da **sync automática / cron 1h**
- robustez final do fluxo **reset-my-account**
- alinhamento final de **README/operação**
- acabamento técnico residual (ex.: `tailwind.config.ts` ainda com `require()`)

---

## 2. Evolução quantitativa

| Métrica | Versão antiga | Versão atual | Evolução |
|---|---:|---:|---:|
| Arquivos no projeto | 119 | 142 | +23 |
| Arquivos adicionados | — | 24 | +24 |
| Arquivos modificados | — | 36 | +36 |
| Arquivos removidos | — | 1 | -1 |
| Rotas mapeadas | 16 | 18 | +2 |
| Testes identificados | 1 | 25 | +24 |
| Edge Functions | 2 | 3 | +1 |
| Migrations SQL | 7 | 23 | +16 |

### Leitura rápida dos números
- O projeto ganhou **24 arquivos novos** e teve **36 arquivos alterados**.
- O número de migrations praticamente **triplicou** (7 → 23), mostrando forte evolução de backend e regras de dados.
- A base de testes saiu de **1 teste placeholder** para **25 testes úteis**.
- As rotas cresceram de **16 para 18**, refletindo novas superfícies funcionais, como `/termos` e `/demandas/editar/:id`.

---

## 3. Changelog por domínio

## 3.1. Plataforma, arquitetura e base do produto
**Nível de evolução:** Alto

### O que mudou
- A base do projeto permaneceu em **React + Vite + TypeScript + Supabase**, mas ganhou mais maturidade operacional.
- O `README.md` deixou de ser um placeholder e passou a documentar:
  - stack
  - rotas
  - edge functions
  - cron
  - onboarding
  - consentimento
  - dados públicos
  - exclusão/reset de conta
- O roteamento passou a usar **lazy loading** para todas as páginas principais.

### Resultado
A versão atual tem mais cara de produto em consolidação, enquanto a versão antiga ainda parecia um projeto acelerado por geração e com pouca documentação.

---

## 3.2. Auth, sessão e onboarding
**Nível de evolução:** Muito alto

### O que mudou em relação à versão antiga
- `AuthContext.tsx` foi endurecido para reduzir corridas, travamentos e fetch duplicado.
- Houve centralização do carregamento de perfil e correção de deadlocks.
- `Login.tsx` foi simplificado para usar o estado do contexto em vez de queries redundantes.
- `Register.tsx` ganhou:
  - tratamento explícito de **repeated signup**
  - feedback correto para conta já existente
  - `emailRedirectTo`
  - aceite obrigatório de termos
  - melhor UX de confirmação
- `Validate.tsx` ficou mais consistente e mais seguro no fluxo de vínculo.

### Evolução funcional
**Antes:** onboarding e auth eram funcionais, mas frágeis.  
**Agora:** o fluxo está muito mais previsível e resiliente.

---

## 3.3. LGPD, consentimento, visibilidade e termos
**Nível de evolução:** Muito alto

### O que mudou
- Criação da página **`/termos`**.
- Inclusão de `terms_accepted_at` e `terms_version`.
- Persistência real do aceite em `registration_intents` e no consumo do vínculo.
- Controle de visibilidade do associado no diretório por `directory_visible`.
- Seção de consentimento e visibilidade no perfil.
- Possibilidade de aceite retroativo para contas legadas.

### Resultado
Esse bloco praticamente **não existia de forma madura** na versão antiga.  
Na versão atual, ele já opera como regra real de produto.

---

## 3.4. Busca de associados e diretório
**Nível de evolução:** Alto

### O que mudou
- A busca saiu do modelo simples client-side e foi para a RPC `search_associates`.
- Foram incorporados:
  - `unaccent`
  - `pg_trgm`
  - ranking por relevância
  - full-text search
  - peso para `business_description`
  - suporte forte a CPF/CNPJ normalizado
- `Associates.tsx` e `AssociateDetail.tsx` passaram a respeitar visibilidade do diretório.

### Resultado
**Antes:** busca básica e mais sujeita a falhas.  
**Agora:** busca muito mais inteligente, aderente ao caso de uso e conectada às regras de visibilidade.

---

## 3.5. Perfil público editável
**Nível de evolução:** Muito alto

### O que mudou
- Foi criada a coluna `public_overrides` em `profiles`.
- `/perfil` passou a permitir editar dados públicos como:
  - nome fantasia
  - descrição
  - telefone
  - e-mail
- `/associados/:id` agora resolve exibição por:
  1. override do perfil
  2. fallback da base sincronizada

### Resultado
Esse foi um dos melhores avanços da rodada: o sistema passou a permitir personalização pública **sem brigar com a sync**.

---

## 3.6. Sync Google Sheets, logs e admin
**Nível de evolução:** Alto, com pendências operacionais

### O que mudou
- Parser CSV ficou mais robusto.
- Houve normalização melhor de CPF/CNPJ.
- A sync passou a operar com:
  - `trigger_source`
  - `content_hash`
  - status `skipped`
  - timeout cooperativo
  - cancelamento
  - reconciliação de tasks órfãs
  - bloqueio de concorrência
- `Admin.tsx` ganhou:
  - feedback melhor
  - status mais claros
  - UX melhor para sync manual e cancelamento
  - contagem operacional

### Resultado
**Antes:** sync funcional, porém frágil.  
**Agora:** sync muito mais séria e instrumentada.

### Ressalva
A documentação e os textos ainda carregam ambiguidade entre:
- cron interno / `pg_cron`
- cron externo / 1 hora

Então o bloco evoluiu muito, mas ainda pede consolidação operacional final.

---

## 3.7. Demandas, interesses e notificações
**Nível de evolução:** Alto

### O que mudou
- Foram adicionados índices para demandas.
- O mural passou a reforçar demandas abertas.
- `Minhas Demandas` ganhou editar/excluir/encerrar melhor.
- Foi criada a tabela de **notifications** com trigger para notificar interesses.
- `Interests.tsx` passou a ter melhor modelagem para enviados/recebidos.
- Dashboard passou a alertar sobre interesses não lidos.

### Resultado
Esse domínio deixou de ser apenas um mural simples e começou a funcionar mais como fluxo de negócio real.

---

## 3.8. WhatsApp e UX de contato
**Nível de evolução:** Médio-alto

### O que mudou
- O contato foi consolidado em `src/lib/whatsapp.ts`.
- O padrão adotado é `https://wa.me/<número>`.
- `DemandDetail.tsx` recebeu ajuste visual no bloco de interesse + CTA de WhatsApp.
- `AssociateDetail.tsx` também usa o util central.

### Resultado
O projeto ficou mais consistente e alinhado com o padrão correto de click-to-chat.

### Nota importante
O histórico registra que o bloqueio observado estava ligado ao sandbox/iframe do preview, e não ao codebase final. Mesmo assim, o ponto operacional continua dependente de validação no site publicado.

---

## 3.9. Segurança e hardening
**Nível de evolução:** Alto, porém ainda parcial

### O que mudou
- `bootstrap-admin` foi desativada por segurança.
- `sync-google-sheets` deixou de aceitar fluxo frouxo sem auth adequada.
- Houve endurecimento de `AuthContext`, onboarding e perfis ausentes.
- `ensure_user_profile()` foi introduzida.

### Resultado
A versão atual é **menos perigosa** do que a antiga.

### Limites
Ainda não dá para tratar o projeto como “hardening concluído”, porque permanecem arestas técnicas e operacionais.

---

## 3.10. Performance, lazy loading e build
**Nível de evolução:** Alto

### O que mudou
- `App.tsx` passou a usar `React.lazy` e `Suspense`.
- `vite.config.ts` ganhou `manualChunks`.
- O bundle ficou mais segmentado e cacheável.

### Resultado
A versão atual está em outro patamar em relação ao bundle monolítico da versão antiga.

---

## 3.11. Testes e QA
**Nível de evolução:** Muito alto

### O que mudou
A versão antiga tinha apenas:
- `src/test/example.test.ts` com 1 teste placeholder

A versão atual tem 4 suítes reais:
- `normalize.test.ts` — 8 testes
- `whatsapp.test.ts` — 7 testes
- `ProtectedRoute.test.tsx` — 6 testes
- `Terms.test.tsx` — 4 testes

**Total:** 25 testes úteis

### Resultado
Foi um dos maiores saltos de maturidade entre as duas versões.

---

## 3.12. Documentação
**Nível de evolução:** Muito alto

### O que mudou
- O `README.md` antigo era praticamente vazio.
- O atual descreve stack, rotas, edge functions, cron, onboarding, LGPD, exclusão de conta, testes e observações técnicas.

### Resultado
A manutenção e o onboarding técnico ficaram muito mais viáveis.

### Ressalva
Ainda existe necessidade de alinhar definitivamente o modelo real da sync automática.

---

## 4. Evolução por tema — visão resumida

| Tema | Estado antigo | Estado atual | Evolução |
|---|---|---|---|
| Auth / onboarding | funcional, mas frágil | endurecido e mais previsível | Muito alta |
| LGPD / termos | quase inexistente como sistema real | operacional e persistido | Muito alta |
| Busca de associados | básica | inteligente, ranqueada, visibilidade integrada | Alta |
| Perfil público | inexistente | overrides públicos com fallback | Muito alta |
| Sync / admin | funcional, porém frágil | robusta, com hash, skip, timeout, cancel | Alta |
| Demandas / interesses | razoável | mais madura, com notificações | Alta |
| WhatsApp | simples | centralizado e mais consistente | Média-alta |
| Testes | 1 placeholder | 25 testes úteis | Muito alta |
| README | vazio | operacional e detalhado | Muito alta |
| Hardening geral | baixo | bem melhor, mas ainda parcial | Média-alta |

---

## 5. Cobertura dos prompts e do que foi pedido

### O que foi claramente executado
- hardening de auth/onboarding
- repeated signup
- profile ausente
- aceite de termos
- `/termos`
- visibilidade no diretório
- `public_overrides`
- busca inteligente
- lazy loading
- `manualChunks`
- README real
- testes úteis
- UX de WhatsApp
- botão “Excluir conta” e edge function de reset

### O que foi executado, mas ainda com ressalvas
- sync 1h / modelo operacional final
- cancelamento no runtime real
- reset completo da conta de forma totalmente fiel à regra de negócio
- documentação 100% coerente com a operação final

### O que ainda merece nova rodada
- alinhar definitivamente o modelo do cron
- revisar a ordem e a cobertura do `reset-my-account`
- fechar o acabamento técnico residual

---

## 6. Pendências e riscos remanescentes

### Pendente crítico
1. **Reset de conta ainda pede refinamento**
   - a ordem das exclusões pode deixar estado parcial se `deleteUser()` falhar
   - `registration_intents` não parece coberta de forma totalmente abrangente
   - demandas do usuário não parecem tratadas explicitamente

### Pendente importante
2. **Modelo da sync automática precisa ser consolidado**
   - 1 hora é o modelo desejado
   - README/UI ainda trazem narrativa parcialmente ambígua

### Pendente técnico
3. **Acabamento final de hardening**
   - `tailwind.config.ts` ainda usa `require()`
   - warnings residuais e validação final ainda merecem fechamento

---

## 7. Conclusão final

A comparação mostra uma evolução forte e consistente.

**Resumo objetivo:**
- o projeto antigo era um **MVP promissor, porém frágil**
- o projeto atual é um **MVP evoluído, funcional e muito mais maduro**
- a evolução foi **real e substancial**
- o SaaS ganhou backend, regras, UX, testes, documentação e estrutura
- o que falta agora já não é “construção”, e sim **consolidação final**

### Leitura final
Se o projeto antigo era algo como:
- **bom protótipo com riscos**

o projeto atual já pode ser classificado como:
- **produto funcional em consolidação, com boa base para seguir evoluindo**

---

## 8. Apêndice — arquivos adicionados

- src/components/ui/hero-shutter-text.tsx
- src/components/ui/the-infinite-grid.tsx
- src/pages/Terms.tsx
- src/test/ProtectedRoute.test.tsx
- src/test/Terms.test.tsx
- src/test/normalize.test.ts
- src/test/whatsapp.test.ts
- supabase/functions/reset-my-account/index.ts
- supabase/migrations/20260401131347_b9f932fb-beea-4dc0-af5c-c801a7ecb34a.sql
- supabase/migrations/20260401132616_a1c0850f-67ec-404f-993b-1848d772dd4d.sql
- supabase/migrations/20260401132635_ef644a04-26fb-4b68-95c3-fcf27631c148.sql
- supabase/migrations/20260401134739_679ac951-84cd-4903-b792-0a1fa133b7c5.sql
- supabase/migrations/20260401135239_88db0503-c8ec-4ba7-8c36-8248f25154d6.sql
- supabase/migrations/20260401171307_bdd47b04-09d6-4468-a915-5c003c359b56.sql
- supabase/migrations/20260402185415_61fd2020-5c3f-4c9e-aa38-bc31cbe9c975.sql
- supabase/migrations/20260403173406_480e5356-f7cd-4113-a536-7531aa150b04.sql
- supabase/migrations/20260403173637_cd3a2903-4263-4b34-9b16-1ab50341dac5.sql
- supabase/migrations/20260403174424_6e85ca16-5658-40ec-bc62-52209b797401.sql
- supabase/migrations/20260403194435_2dc274ed-04e2-44d8-a175-d6ba671a9d29.sql
- supabase/migrations/20260403211036_e4e65dad-0388-4114-a56e-90950c0b6c5a.sql
- supabase/migrations/20260403221737_c912e2ed-be64-4c85-afc6-ba54cc12bc44.sql
- supabase/migrations/20260403233250_09fbacb1-9e77-4beb-8f09-c74a1f68ca18.sql
- supabase/migrations/20260403235921_bee8328a-295d-407a-9ecb-debb471131bb.sql
- supabase/migrations/20260404011321_05eb1ed0-f3cb-4c80-9776-97a35cc27416.sql

## 9. Apêndice — arquivo removido

- src/test/example.test.ts

## 10. Apêndice — arquivos modificados

- .env
- README.md
- bun.lock
- index.html
- package.json
- src/App.tsx
- src/components/demands/DemandStatusBadge.tsx
- src/components/layout/AppLayout.tsx
- src/components/shared/EmptyState.tsx
- src/components/ui/button.tsx
- src/components/ui/card.tsx
- src/components/ui/command.tsx
- src/components/ui/input.tsx
- src/components/ui/textarea.tsx
- src/contexts/AuthContext.tsx
- src/index.css
- src/integrations/supabase/types.ts
- src/pages/Admin.tsx
- src/pages/AssociateDetail.tsx
- src/pages/Associates.tsx
- src/pages/CreateDemand.tsx
- src/pages/Dashboard.tsx
- src/pages/DemandDetail.tsx
- src/pages/Demands.tsx
- src/pages/Interests.tsx
- src/pages/Landing.tsx
- src/pages/Login.tsx
- src/pages/MyDemands.tsx
- src/pages/NotFound.tsx
- src/pages/Profile.tsx
- src/pages/Register.tsx
- src/pages/Validate.tsx
- supabase/functions/bootstrap-admin/index.ts
- supabase/functions/sync-google-sheets/index.ts
- tailwind.config.ts
- vite.config.ts

## 11. Apêndice — script Python de gráficos

O arquivo separado `acirv_changelog_charts.py` acompanha este material e pode ser executado assim:

```bash
python acirv_changelog_charts.py "Conecta ACIRV - ANTIGO.zip" "Ecossistema ACIRV - ATUALIZADO 040420260321.zip" --output_dir ./acirv_changelog_output
```

Ele gera:
- `chart_metrics.png`
- `chart_area_files.png`
- `chart_area_lines.png`
- `summary.json`

Esses gráficos foram usados para alimentar este relatório.
