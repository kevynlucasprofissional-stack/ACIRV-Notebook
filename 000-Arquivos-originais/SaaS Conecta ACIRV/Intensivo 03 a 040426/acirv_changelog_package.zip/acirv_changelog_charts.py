
from __future__ import annotations
import argparse, zipfile, tempfile, shutil, re, json, difflib
from pathlib import Path
from collections import Counter, defaultdict
import matplotlib.pyplot as plt

def extract_zip(zip_path: Path, dest: Path):
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(dest)

def read_files(root: Path):
    return {p.relative_to(root).as_posix(): p for p in root.rglob('*') if p.is_file()}

def area(path: str) -> str:
    if path.startswith('supabase/functions/'):
        return 'Edge Functions'
    if path.startswith('supabase/migrations/'):
        return 'Migrations'
    if path.startswith('src/pages/'):
        return 'Pages'
    if path.startswith('src/components/'):
        return 'Components'
    if path.startswith('src/contexts/'):
        return 'Contexts'
    if path.startswith('src/lib/'):
        return 'Lib'
    if path.startswith('src/test/'):
        return 'Tests'
    if path.startswith('src/integrations/'):
        return 'Integrations'
    if path.startswith('src/'):
        return 'Source other'
    if path in ('README.md', 'package.json', 'vite.config.ts', 'tailwind.config.ts', 'eslint.config.js'):
        return 'Config & Docs'
    return 'Other'

def count_changes(a_text: str, b_text: str):
    sm = difflib.SequenceMatcher(None, a_text.splitlines(), b_text.splitlines())
    added = removed = 0
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'insert':
            added += j2 - j1
        elif tag == 'delete':
            removed += i2 - i1
        elif tag == 'replace':
            removed += i2 - i1
            added += j2 - j1
    return added, removed

def count_tests(root: Path):
    total = 0
    files = {}
    for p in (root / 'src/test').glob('*'):
        if p.suffix in ['.ts', '.tsx']:
            txt = p.read_text(errors='ignore')
            cnt = len(re.findall(r'\b(?:it|test)\s*\(', txt))
            if cnt:
                total += cnt
                files[p.name] = cnt
    return total, files

def count_routes(root: Path):
    app = (root / 'src/App.tsx').read_text(errors='ignore')
    return len(re.findall(r'path="[^"]+"', app))

def count_edge_functions(root: Path):
    p = root / 'supabase/functions'
    if not p.exists():
        return 0
    return len([d for d in p.iterdir() if d.is_dir()])

def count_migrations(root: Path):
    p = root / 'supabase/migrations'
    return len(list(p.glob('*.sql'))) if p.exists() else 0

def analyze(old_zip: Path, new_zip: Path, output_dir: Path):
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        old_dir = td / 'old'
        new_dir = td / 'new'
        old_dir.mkdir()
        new_dir.mkdir()
        extract_zip(old_zip, old_dir)
        extract_zip(new_zip, new_dir)

        old_files = read_files(old_dir)
        new_files = read_files(new_dir)

        added = sorted(set(new_files) - set(old_files))
        removed = sorted(set(old_files) - set(new_files))
        modified = sorted(f for f in set(old_files) & set(new_files) if old_files[f].read_bytes() != new_files[f].read_bytes())

        change_records = []
        for f in modified:
            a = old_files[f].read_text(errors='ignore')
            b = new_files[f].read_text(errors='ignore')
            add, rem = count_changes(a, b)
            change_records.append((f, add, rem, area(f)))
        for f in added:
            b = new_files[f].read_text(errors='ignore')
            change_records.append((f, len(b.splitlines()), 0, area(f)))
        for f in removed:
            a = old_files[f].read_text(errors='ignore')
            change_records.append((f, 0, len(a.splitlines()), area(f)))

        by_area_files = Counter(area(f) for f in added + removed + modified)
        by_area_lines = defaultdict(lambda: [0,0])
        for f, add, rem, ar in change_records:
            by_area_lines[ar][0] += add
            by_area_lines[ar][1] += rem

        metrics = {
            'files_total_old': len(old_files),
            'files_total_new': len(new_files),
            'files_added': len(added),
            'files_removed': len(removed),
            'files_modified': len(modified),
            'routes_old': count_routes(old_dir),
            'routes_new': count_routes(new_dir),
            'tests_old': count_tests(old_dir)[0],
            'tests_new': count_tests(new_dir)[0],
            'edge_functions_old': count_edge_functions(old_dir),
            'edge_functions_new': count_edge_functions(new_dir),
            'migrations_old': count_migrations(old_dir),
            'migrations_new': count_migrations(new_dir),
        }

        output_dir.mkdir(parents=True, exist_ok=True)
        # Chart 1
        fig, ax = plt.subplots(figsize=(8,4.8))
        names = ['Routes', 'Tests', 'Edge Functions', 'Migrations', 'Files']
        old_vals = [metrics['routes_old'], metrics['tests_old'], metrics['edge_functions_old'], metrics['migrations_old'], metrics['files_total_old']]
        new_vals = [metrics['routes_new'], metrics['tests_new'], metrics['edge_functions_new'], metrics['migrations_new'], metrics['files_total_new']]
        x = range(len(names))
        width = 0.38
        ax.bar([i - width/2 for i in x], old_vals, width, label='Old')
        ax.bar([i + width/2 for i in x], new_vals, width, label='Current')
        ax.set_title('Evolution of Key Project Metrics')
        ax.set_xticks(list(x))
        ax.set_xticklabels(names, rotation=0)
        ax.legend()
        ax.grid(axis='y', alpha=0.25)
        fig.tight_layout()
        fig.savefig(output_dir / 'chart_metrics.png', dpi=180)
        plt.close(fig)

        # Chart 2
        fig, ax = plt.subplots(figsize=(8,5.6))
        areas = [k for k,_ in by_area_files.most_common()]
        values = [by_area_files[a] for a in areas]
        ax.barh(areas, values)
        ax.set_title('Changed Files by Area')
        ax.grid(axis='x', alpha=0.25)
        fig.tight_layout()
        fig.savefig(output_dir / 'chart_area_files.png', dpi=180)
        plt.close(fig)

        # Chart 3
        fig, ax = plt.subplots(figsize=(8,5.6))
        areas = sorted(by_area_lines.keys(), key=lambda a: by_area_lines[a][0]+by_area_lines[a][1], reverse=True)
        adds = [by_area_lines[a][0] for a in areas]
        rems = [by_area_lines[a][1] for a in areas]
        y = range(len(areas))
        ax.barh(y, adds, label='Added/changed lines')
        ax.barh(y, [-r for r in rems], label='Removed lines')
        ax.set_yticks(list(y))
        ax.set_yticklabels(areas)
        ax.set_title('Approximate Diff Volume by Area')
        ax.axvline(0, color='black', linewidth=0.8)
        ax.legend()
        fig.tight_layout()
        fig.savefig(output_dir / 'chart_area_lines.png', dpi=180)
        plt.close(fig)

        summary = {
            'metrics': metrics,
            'added_files': added,
            'removed_files': removed,
            'modified_files': modified,
            'changed_files_by_area': by_area_files,
            'changed_lines_by_area': {k: {'added': v[0], 'removed': v[1]} for k,v in by_area_lines.items()},
            'test_files_old': count_tests(old_dir)[1],
            'test_files_new': count_tests(new_dir)[1],
        }
        (output_dir / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
        return summary

def main():
    parser = argparse.ArgumentParser(description='Generate comparison charts for two ACIRV SaaS codebase zip files.')
    parser.add_argument('old_zip', type=Path)
    parser.add_argument('new_zip', type=Path)
    parser.add_argument('--output_dir', type=Path, default=Path('./acirv_changelog_output'))
    args = parser.parse_args()
    summary = analyze(args.old_zip, args.new_zip, args.output_dir)
    print(json.dumps(summary['metrics'], indent=2, ensure_ascii=False))
    print(f'Charts and summary written to: {args.output_dir}')

if __name__ == '__main__':
    main()
